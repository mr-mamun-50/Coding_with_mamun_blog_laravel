<?php $__env->startSection('title'); ?>
    messages
<?php $__env->stopSection(); ?>

<?php
    $page = 'messages';
?>

<?php $__env->startSection('mainpart'); ?>
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h4 class="card-title">All messages</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered" id="dataTable">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Photo</th>
                        <th>Name & Email</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td>
                                <?php if($message->user_photo == null): ?>
                                    <img src="<?php echo e(asset('images/user_photos/user.png')); ?>" alt="" style="width: 50px"
                                        class="rounded-circle">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/user_photos/' . $message->user_photo)); ?>" alt=""
                                        style="width: 50px" class="rounded-circle">
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($message->user_name); ?> <br>
                                <small><?php echo e($message->user_email); ?></small>
                            </td>
                            <td><?php echo e($message->subject); ?></td>
                            <td>
                                <?php
                                    echo $message->message;
                                ?>
                            </td>

                            <td>
                                <div class="d-flex">
                                    <a class="mr-2 btn btn-info btn-sm" href="mailto:<?php echo e($message->user_email); ?>"
                                        target="blank">
                                        <i class="fas fa-envelope"></i>
                                    </a>
                                    <form action="<?php echo e(route('messages.destroy', $message->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button type="submit" class="delete btn btn-danger btn-sm"><i
                                                class="fa fa-trash"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/admin/messages.blade.php ENDPATH**/ ?>