<?php $__env->startSection('mainSection'); ?>
    <div class="py-4"></div>
    <section class="section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="mb-5 col-lg-9 mb-lg-0">
                    <article>
                        <div class="mb-4 post-slider">
                            <img src="<?php echo e(asset('post_thumbnails/' . $post->thumbnail)); ?>" class="card-img" alt="post-thumb">
                        </div>

                        <h1 class="h2"><?php echo e($post->title); ?></h1>
                        <ul class="my-3 card-meta list-inline">
                            <li class="list-inline-item">
                                <i class="ti-calendar"></i><?php echo e(date('d M Y', strtotime($post->created_at))); ?>

                            </li>
                            <li class="list-inline-item">
                                Category: <b class="text-primary"><?php echo e($post->category_name); ?></b>
                            </li>
                        </ul>
                        <h4 class="card-text"><?php echo e($post->subtitle); ?></h4>
                        <div class="content">
                            <p>
                                <?php
                                    echo $post->description;
                                ?>
                            </p>
                        </div>
                    </article>

                </div>

                <div class="col-lg-9 col-md-12">
                    <div class="pt-5 mt-4 mb-5 border-top">
                        <h3 class="mb-4">Comments</h3>

                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="pb-4 mb-4 media d-block d-sm-flex">
                                <a class="mb-3 mr-2 d-inline-block mb-md-0" href="#">
                                    <?php if($comment->user_photo): ?>
                                        <img src="<?php echo e(asset('images/user_photos/' . $comment->user_photo)); ?>" alt=""
                                            class="rounded-circle mr-3" style="height: 30px">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/user_photos/user.png')); ?>" alt=""
                                            class="rounded-circle mr-3" style="height: 30px">
                                    <?php endif; ?>
                                </a>
                                <div class="media-body">
                                    <a href="#!" class="mb-3 h4 d-inline-block"><?php echo e($comment->user_name); ?></a>
                                    <p>
                                        <?php
                                            echo $comment->comment;
                                        ?>
                                    </p>
                                    <small class="mr-3 text-black-600 font-weight-600">
                                        <?php echo e(date('d M Y', strtotime($comment->created_at))); ?>

                                    </small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($comments->links('pagination::bootstrap-5')); ?>

                    </div>

                    <div>
                        <h3 class="mb-4">Leave a Reply</h3>
                        <form action="<?php echo e(route('comment_store', $post->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <textarea class="summernote shadow-none form-control" name="comment" rows="7" required></textarea>
                            </div>

                            <button class="btn btn-primary" type="submit">Comment Now</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/user/single_post_view.blade.php ENDPATH**/ ?>