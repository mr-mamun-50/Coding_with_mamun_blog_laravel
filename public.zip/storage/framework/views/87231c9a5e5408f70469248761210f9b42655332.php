<?php $__env->startSection('mainSection'); ?>
    <section class="section-sm">
        <div class="py-4"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="mb-5 col-lg-8 mb-lg-0">
                    <h1 class="mb-4 h2">Showing items from <mark><?php echo e($posts->first()->category_name); ?></mark></h1>

                    <?php $__currentLoopData = $filtered_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="mb-4 card">
                            <div class="post-slider">
                                <img src="<?php echo e(asset('post_thumbnails/' . $post->thumbnail)); ?>" class="card-img-top"
                                    alt="post-thumb">
                            </div>
                            <div class="card-body">
                                <h3 class="mb-3"><a class="post-title"
                                        href="<?php echo e(route('single_post_view', $post->id)); ?>"><?php echo e($post->title); ?></a>
                                </h3>
                                <ul class="card-meta list-inline">

                                    <li class="list-inline-item">
                                        <i class="ti-calendar"></i><?php echo e(date('d M Y', strtotime($post->created_at))); ?>

                                    </li>
                                    <li class="list-inline-item">
                                        Category: <b class="text-primary"><?php echo e($post->category_name); ?></b>
                                    </li>
                                </ul>
                                <p class="card-text"><?php echo e($post->subtitle); ?></p>
                                <a href="<?php echo e(route('single_post_view', $post->id)); ?>" class="btn btn-outline-primary">Read
                                    More</a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-5">
                        <?php echo e($filtered_posts->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>

                
                <?php echo $__env->make('layouts.rightbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/user/filter_by_category.blade.php ENDPATH**/ ?>