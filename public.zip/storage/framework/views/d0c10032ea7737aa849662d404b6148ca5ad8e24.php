<!-- JS Plugins -->
<script src="<?php echo e(asset('usr_assets/plugins/jQuery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('usr_assets/plugins/bootstrap/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('usr_assets/plugins/slick/slick.min.js')); ?>"></script>

<script src="<?php echo e(asset('usr_assets/plugins/instafeed/instafeed.min.js')); ?>"></script>


<!-- Main Script -->
<script src="<?php echo e(asset('usr_assets/js/script.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\coding_with_mamun_blog\resources\views/layouts/includes/scripts.blade.php ENDPATH**/ ?>