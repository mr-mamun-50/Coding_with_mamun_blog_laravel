<aside class="col-lg-4 sidebar-home">
    <!-- Search -->
    <div class="widget">
        <h4 class="widget-title"><span>Search</span></h4>
        <form action="#!" class="widget-search">
            <input class="mb-3" id="search-query" name="s" type="search" placeholder="Type &amp; Hit Enter...">
            <i class="ti-search"></i>
            <button type="submit" class="btn btn-primary btn-block">Search</button>
        </form>
    </div>

    <!-- about me -->
    <div class="widget widget-about">
        <h4 class="widget-title">Hi, I am Mamun!</h4>
        <img class="img-fluid" src="<?php echo e(asset('usr_assets/images/author.jpg')); ?>" alt="Themefisher">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vel in in donec iaculis tempus odio
            nunc laoreet . Libero ullamcorper.</p>
        <ul class="mb-3 list-inline social-icons">

            <li class="list-inline-item"><a href="#"><i class="ti-facebook"></i></a></li>

            <li class="list-inline-item"><a href="#"><i class="ti-twitter-alt"></i></a></li>

            <li class="list-inline-item"><a href="#"><i class="ti-linkedin"></i></a></li>

            <li class="list-inline-item"><a href="#"><i class="ti-github"></i></a></li>

            <li class="list-inline-item"><a href="#"><i class="ti-youtube"></i></a></li>

        </ul>
        <a href="about-me.html" class="mb-2 btn btn-primary">About me</a>
    </div>


    <!-- recent post -->
    <div class="widget">
        <h4 class="widget-title">Recent Post</h4>

        <?php for($i = 0; $i < 3; $i++): ?>
            <!-- post-item -->
            <article class="widget-card">
                <div class="d-flex">
                    <img class="card-img-sm" src="<?php echo e(asset('post_thumbnails/' . $recentPost[$i]->thumbnail)); ?>">
                    <div class="ml-3">
                        <h5><a class="post-title"
                                href="<?php echo e(route('single_post_view', $recentPost[$i]->id)); ?>"><?php echo e($recentPost[$i]->title); ?></a>
                        </h5>
                        <ul class="mb-0 card-meta list-inline">
                            <li class="mb-0 list-inline-item">
                                <i class="ti-calendar"></i> <?php echo e($recentPost[$i]->created_at->format('d M Y')); ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </article>
        <?php endfor; ?>

    </div>

    <!-- categories -->
    <div class="widget widget-categories">
        <h4 class="widget-title"><span>Categories</span></h4>
        <ul class="list-unstyled widget-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                    $postCount = DB::table('posts')
                        ->where('category_id', $category->id)
                        ->count();
                ?>

                <li><a href="<?php echo e(route('filter_by_category', $category->id)); ?>" class="d-flex"><?php echo e($category->name); ?>

                        <small class="ml-auto">(<?php echo e($postCount); ?>)</small></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>


</aside>
<?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/layouts/rightbar.blade.php ENDPATH**/ ?>