<?php $__env->startSection('title'); ?>
    Question answers |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainSection'); ?>
    <!-- Answer section -->
    <div class="py-4"></div>
    <section class="section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="mb-5 col-lg-9 mb-lg-0">
                    <article>

                        <h1 class="h2"><?php echo e($question->question); ?></h1>
                        <ul class="mt-4 card-meta list-inline">
                            <li class="list-inline-item">
                                <a href="#" class="card-meta-author">
                                    <?php if($question->user_photo): ?>
                                        <img src="<?php echo e(asset('images/user_photos/' . $question->user_photo)); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/user_photos/user.png')); ?>">
                                    <?php endif; ?>
                                    <span><?php echo e($question->user_name); ?></span>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <i class="ti-calendar"></i><?php echo e(date('d M, Y', strtotime($question->created_at))); ?>

                            </li>
                            <li class="list-inline-item text-primary">
                                <i class="ti-bookmark"></i><?php echo e($question->category_name); ?>

                            </li>
                        </ul>

                    </article>

                </div>

                <div class="col-lg-9 col-md-12">
                    <div class="pt-5 mt-4 mb-5 border-top">
                        <h3 class="mb-4">Answers</h3>

                        <?php if($answers->count() > 0): ?>
                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mt-4 card card-body">
                                    <div class="media d-block d-sm-flex">
                                        <a class="mb-3 mr-2 d-inline-block mb-md-0" href="#">
                                            <?php if($answer->user_photo): ?>
                                                <img src="<?php echo e(asset('images/user_photos/' . $answer->user_photo)); ?>"
                                                    class="mr-3 avater">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/user_photos/user.png')); ?>" class="mr-3 avater">
                                            <?php endif; ?>
                                        </a>
                                        <div class="media-body">
                                            <div class="mb-4 d-flex justify-content-between align-items-center">
                                                <span>
                                                    <a href="#!"
                                                        class="mb-3 h4 d-inline-block"><?php echo e($answer->user_name); ?></a>
                                                    <small class="ml-2 text-black-800 font-weight-600">
                                                        <?php echo e(date('d M, Y', strtotime($answer->created_at))); ?>

                                                    </small>
                                                </span>

                                                <?php if($answer->user_id === auth()->user()->id): ?>
                                                    <form action="<?php echo e(route('question_answer_delete', $answer->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="bg-white border-0 text-danger delete"> <i
                                                                class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                            <p>
                                                <?php
                                                    echo $answer->answer;
                                                ?>
                                            </p>
                                            <hr class="my-3">
                                            <div class="">

                                                <?php
                                                    $likes = DB::table('question_answer_likes')
                                                        ->where('answer_id', $answer->id)
                                                        ->get();
                                                    $liker_user = DB::table('question_answer_likes')
                                                        ->where('answer_id', $answer->id)
                                                        ->where('user_id', auth()->user()->id)
                                                        ->first();
                                                ?>

                                                <?php if($liker_user): ?>
                                                    <a href="<?php echo e(route('question_answer_unlike', $answer->id)); ?>">
                                                        <i class="fa fa-heart text-danger"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('question_answer_like', $answer->id)); ?>">
                                                        <i class="far fa-heart text-dark"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <span class="ml-1">(<?php echo e($likes->count()); ?>)</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>No answer found</p>
                        <?php endif; ?>

                    </div>

                    <div>
                        <h3 class="pt-4 mb-4">Leave an answer</h3>

                        <form action="<?php echo e(route('question_answer_store', $question->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <textarea class="shadow-none summernote form-control" name="answer" rows="7" required></textarea>
                            </div>

                            <button class="btn btn-primary" type="submit">Submit Answer</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/user/question_answers.blade.php ENDPATH**/ ?>