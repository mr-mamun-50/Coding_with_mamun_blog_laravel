<?php $__env->startSection('title'); ?>
    Questions |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mainSection'); ?>
    <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- questions section -->
    <section class="section-sm">
        <div class="container">
            <div class="row justify-content-center">
                <div class="mb-5 col-lg-8 mb-lg-0">
                    <h2 class="h5 section-title">Questions</h2>

                    <div class="mb-4 d-flex justify-content-between align-items-center">
                        <h3 class="h5">Frequently asked questions</h5>
                            <a href="#askQuestion" class="btn btn-primary">Ask a Question</a>
                    </div>


                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-4 border card">
                            <div class="card-body">
                                <div class="mb-4 d-flex justify-content-between align-items-center">
                                    <a href="<?php echo e(route('question_answers', $question->id)); ?>"
                                        class="btn-link h4"><?php echo e($question->question); ?></a>
                                    <?php if($question->user_id === auth()->user()->id): ?>
                                        <form action="<?php echo e(route('question_delete', $question->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="bg-white border-0 text-danger delete"> <i
                                                    class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>

                                <ul class="mt-4 card-meta list-inline">
                                    <li class="list-inline-item">
                                        <a href="#" class="card-meta-author">
                                            <?php if($question->user_photo): ?>
                                                <img src="<?php echo e(asset('images/user_photos/' . $question->user_photo)); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/user_photos/user.png')); ?>">
                                            <?php endif; ?>
                                            <span><?php echo e($question->user_name); ?></span>
                                        </a>
                                    </li>
                                    <li class="list-inline-item">
                                        <i class="ti-calendar"></i><?php echo e(date('d M, Y', strtotime($question->created_at))); ?>

                                    </li>
                                    <li class="list-inline-item text-primary">
                                        <i class="ti-bookmark"></i><?php echo e($question->category_name); ?>

                                    </li>
                                    <li class="list-inline-item text-primary">
                                        <i class="ti-comment"></i>
                                        <?php
                                            $answers = DB::table('question_answers')
                                                ->where('question_id', $question->id)
                                                ->get();
                                            echo count($answers);
                                            if (count($answers) > 1) {
                                                echo ' answers';
                                            } else {
                                                echo ' answer';
                                            }
                                        ?>
                                    </li>
                                </ul>

                                <a href="<?php echo e(route('question_answers', $question->id)); ?>"
                                    class="py-1 mt-4 btn btn-outline-primary btn-sm">See
                                    answers</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-5">
                        <?php echo e($questions->links('pagination::bootstrap-5')); ?>

                    </div>




                    <!-- ask question form -->
                    <h3 class="mb-3 h4" id="askQuestion">Ask a question</h3>

                    <form action="<?php echo e(route('question_store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3 form-group">
                            <select name="category_id" class="form-control  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required>
                                <option disabled selected>Choose Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3 form-group">
                            <textarea class="form-control  <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="question" rows="10"
                                placeholder="Enter question here..."></textarea>
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit Question</button>
                    </form>

                </div>


                
                <?php echo $__env->make('layouts.rightbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\coding_with_mamun_blog\resources\views/user/questions.blade.php ENDPATH**/ ?>